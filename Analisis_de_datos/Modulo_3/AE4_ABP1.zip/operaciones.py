def multiplicacion(x, y):
    return x*y